# Electron Project Template

This directory contain version 1.0.0 of my template directory structure for
Electron (http://electron.atom.io/releases/) based projects. The directory
will contain a skeletal structure that includes the following...

